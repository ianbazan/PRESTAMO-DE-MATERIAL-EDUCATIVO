﻿namespace SistemaPrestamos.Models
{
    public class Usuario
    {
        public int CodUsuario { get; set; }
        public string Contrasenia { get; set; }
    }
}
