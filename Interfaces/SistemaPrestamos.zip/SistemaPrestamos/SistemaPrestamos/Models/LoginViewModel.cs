﻿namespace SistemaPrestamos.Models
{
    public class LoginViewModel
    {
        public string User { get; set; }
        public string Password { get; set; }
    }
}